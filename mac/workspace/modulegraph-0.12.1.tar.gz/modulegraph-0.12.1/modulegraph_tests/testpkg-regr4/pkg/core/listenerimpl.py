""" pkg.listenerimp """
class Listener:
    pass

class ListenerValidator:
    pass
