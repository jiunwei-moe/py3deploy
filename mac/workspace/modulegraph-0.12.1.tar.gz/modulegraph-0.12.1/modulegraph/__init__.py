import pkg_resources
__version__ = pkg_resources.require('modulegraph')[0].version
