OpenGLDemo

OpenGLDemo is probably the simplest possible demonstration of 
using OpenGL from a PyObjC application.  It is a port of Apple's
"CocoaGL" example.  Note that this requires PyOpenGL to be installed.

See:    /Developer/Examples/OpenGL/Cocoa/CocoaGL
        http://pyopengl.sourceforge.net/

The source of this application demonstrates
- Using PyOpenGL from Cocoa

Bob Ippolito
bob@redivi.com
