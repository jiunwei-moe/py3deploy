from PyObjCTools import AppHelper

import objc; objc.setVerbose(True)
import AppDelegate
import Circle
import Extras
import ShadowOffsetView
import TLayerDemo
import TLayerView


AppHelper.runEventLoop()
