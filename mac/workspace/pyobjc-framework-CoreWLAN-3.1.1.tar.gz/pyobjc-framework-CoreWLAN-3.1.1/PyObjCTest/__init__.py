""" testsuite for CoreWLAN """
