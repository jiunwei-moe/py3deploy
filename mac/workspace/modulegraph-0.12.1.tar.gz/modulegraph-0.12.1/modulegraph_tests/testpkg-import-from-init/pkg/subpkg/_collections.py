""" pkg.subpkg._collections """

A, B = "A", "B"
