from PyObjCTools import AppHelper

import AppController

# Uncomment the next two lines to make
# PyObjC more verbose, which helps during
# debugging.
import objc
objc.setVerbose(True)


AppHelper.runEventLoop()
