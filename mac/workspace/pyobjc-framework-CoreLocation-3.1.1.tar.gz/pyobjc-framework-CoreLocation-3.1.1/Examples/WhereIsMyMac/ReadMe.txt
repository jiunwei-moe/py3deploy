This example shows how to use the CoreLocation
framework and is a translation in Python
of the example at `"Cocoa with Love"`__

.. __: http://www.cocoawithlove.com/2009/09/whereismymac-snow-leopard-corelocation.html

