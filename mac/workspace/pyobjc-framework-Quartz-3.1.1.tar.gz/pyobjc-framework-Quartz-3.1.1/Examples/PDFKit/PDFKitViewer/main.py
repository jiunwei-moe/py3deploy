from PyObjCTools import NibClassBuilder, AppHelper
import objc
objc.setVerbose(True)

import MyPDFDocument
import AppDelegate

AppHelper.runEventLoop()
