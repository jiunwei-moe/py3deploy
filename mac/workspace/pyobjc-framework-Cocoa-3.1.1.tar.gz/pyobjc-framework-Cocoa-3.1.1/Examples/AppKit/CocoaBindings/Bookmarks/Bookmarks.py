import BookmarksDocument
import DNDTableView
import DNDArrayController

if __name__ == '__main__':
    from PyObjCTools import AppHelper
    AppHelper.runEventLoop()
