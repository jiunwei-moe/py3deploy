
from PyObjCTools.TestSupport import *
from QTKit import *

class TestQTCaptureVideoPreviewOutput (TestCase):
    pass

if __name__ == "__main__":
    main()
