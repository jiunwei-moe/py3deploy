from PyObjCTools import AppHelper

import WhereIsMyMacAppDelegate

AppHelper.runEventLoop()
