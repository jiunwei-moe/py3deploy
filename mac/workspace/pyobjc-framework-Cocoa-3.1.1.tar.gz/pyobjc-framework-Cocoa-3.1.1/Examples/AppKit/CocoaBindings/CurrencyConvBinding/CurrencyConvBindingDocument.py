from Cocoa import NSDocument

class CurrencyConvBindingDocument (NSDocument):
    def windowNibName(self):
        return "CurrencyConvBindingDocument"
