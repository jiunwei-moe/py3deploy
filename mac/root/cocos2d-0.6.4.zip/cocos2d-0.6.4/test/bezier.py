from __future__ import division, print_function, unicode_literals

import cocos
from cocos.path import Bezier

path = Bezier( (100,100), (449,290), (5, 287), (438,27) )
