
skin = [
    ('body', (25, 91), 'gil-cuerpo.png', True, True, 0.5),
    ('lower_arm', (0, 0), 'gil-mano1.png', False, False, 0.5),
    ('upper_arm', (0, 0), 'gil-brazo1.png', False, False, 0.5),
  ]
