from __future__ import division, print_function, unicode_literals

ROWS = 20
COLUMNS = 10
SQUARE_SIZE = 29
MUSIC = True
SOUND = True
