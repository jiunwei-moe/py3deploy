from PyObjCTools import AppHelper

import AppController

AppHelper.runEventLoop()
