from PyObjCTools import AppHelper
import objc; objc.setVerbose(True)

import ABPersonDisplayNameAdditions
import PeopleDataSource
import ServiceWatcher


AppHelper.runEventLoop()
