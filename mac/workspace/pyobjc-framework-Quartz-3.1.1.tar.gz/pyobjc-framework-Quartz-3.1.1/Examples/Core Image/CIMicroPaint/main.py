from PyObjCTools import AppHelper

import CIMicroPaintView
import SampleCIView

import objc; objc.setVerbose(True)

AppHelper.runEventLoop()
