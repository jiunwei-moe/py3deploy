#include "sharedlib.h"

int squared(int x)
{
	return x*x;
}

int doubled(int x)
{
	return x+x;
}

int half(int x)
{
	return x/2;
}
