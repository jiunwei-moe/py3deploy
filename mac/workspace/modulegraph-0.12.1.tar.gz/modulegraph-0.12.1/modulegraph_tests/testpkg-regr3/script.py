from mypkg.distutils import ccompiler
