
skin = [
    ('body', (25, 91), 'gil-cuerpo.png', True, True, 0.5),
  ]
