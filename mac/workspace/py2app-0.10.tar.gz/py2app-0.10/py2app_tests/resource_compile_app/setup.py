from setuptools import setup

setup(
    name='Resources',
    app=['main.py'],
    data_files=['MainMenu.xib'],
)
