import objc; objc.setVerbose(1)
import MHTDocument
from PyObjCTools import AppHelper

AppHelper.runEventLoop()
