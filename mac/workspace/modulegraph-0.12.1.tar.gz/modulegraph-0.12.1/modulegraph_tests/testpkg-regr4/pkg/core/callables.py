""" pkg.callables """

getID, getArgs, getRawFunction, ListenerInadequate, CallArgsInfo = [None]*5
