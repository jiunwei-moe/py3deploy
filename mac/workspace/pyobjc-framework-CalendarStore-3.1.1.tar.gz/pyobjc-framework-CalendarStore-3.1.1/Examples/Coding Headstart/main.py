from PyObjCTools import AppHelper
import objc; objc.setVerbose(True)

import AppController
import CalController

AppHelper.runEventLoop()
