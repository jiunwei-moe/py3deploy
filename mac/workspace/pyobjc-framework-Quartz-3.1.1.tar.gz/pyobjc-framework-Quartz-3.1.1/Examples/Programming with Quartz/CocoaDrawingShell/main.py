from PyObjCTools import AppHelper
import MyView

AppHelper.runEventLoop()
