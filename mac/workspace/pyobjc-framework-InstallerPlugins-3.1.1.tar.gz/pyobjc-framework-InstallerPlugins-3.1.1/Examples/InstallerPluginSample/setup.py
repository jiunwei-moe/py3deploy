"""
This is dummy file, the real setup.py
is in ``Registration``
"""
