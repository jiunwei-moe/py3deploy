SillyBallsSaver

Example showing screen saver in Python

Based on "Silly Balls.saver" by Eric Peyton <epeyton@epicware.com>
    

See:    http://www.epicware.com/macosxsavers.html
        https://developer.apple.com/library/mac/#documentation/UserExperience/Reference/ScreenSaver/Classes/ScreenSaverView_Class/Reference/Reference.html

The source of this application demonstrates
- Writing a ScreenSaver in PyObjC
- Building plug-in bundles in PyObjC

Jason Toffaletti <catalyst@mac.com>
