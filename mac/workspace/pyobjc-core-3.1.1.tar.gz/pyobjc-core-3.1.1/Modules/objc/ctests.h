#ifndef PyObjC_CTESTS_H
#define PyObjC_CTESTS_H

extern int PyObjC_init_ctests(PyObject*);

#endif /* PyObjC_CTESTS_H */

