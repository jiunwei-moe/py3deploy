import os
print file(os.path.join(os.path.dirname(__file__), 'data.txt')).read()
