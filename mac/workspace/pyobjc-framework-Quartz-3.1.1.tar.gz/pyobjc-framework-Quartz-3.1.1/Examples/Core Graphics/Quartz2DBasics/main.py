from PyObjCTools import AppHelper

import MyAppController
import MyView

import objc; objc.setVerbose(True)

AppHelper.runEventLoop()
