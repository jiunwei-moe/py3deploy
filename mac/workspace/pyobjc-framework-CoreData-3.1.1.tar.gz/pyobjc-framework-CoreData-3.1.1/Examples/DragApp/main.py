from PyObjCTools import AppHelper

import DragAppAppDelegate
import DragSupportDataSource

if __name__ == "__main__":
    AppHelper.runEventLoop()
