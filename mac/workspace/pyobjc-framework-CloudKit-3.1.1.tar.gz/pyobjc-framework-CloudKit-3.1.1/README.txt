Wrappers for framework 'CloudKit' in MacOSX 10.10 or later.

These wrappers don't include documentation, please check Apple's documention for information on how to use this framework and PyObjC's documentation for general tips and tricks regarding the translation between Python and (Objective-)C frameworks
