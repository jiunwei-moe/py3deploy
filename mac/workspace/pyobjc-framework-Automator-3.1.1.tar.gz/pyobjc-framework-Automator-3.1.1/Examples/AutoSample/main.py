from PyObjCTools import AppHelper

import Controller

AppHelper.runEventLoop()
