from PyObjCTools import AppHelper
import CGraphController
import CGraphModel
import CGraphView

AppHelper.runEventLoop()
